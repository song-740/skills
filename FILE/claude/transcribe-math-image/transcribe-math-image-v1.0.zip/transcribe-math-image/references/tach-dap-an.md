# Tách các phương án trả lời

## Mục đích

Quy định cách xuống dòng khi nhiều phương án trả lời xuất hiện trên cùng một dòng trong ảnh nguồn.

Mục tiêu là giúp mỗi phương án nằm trên một dòng riêng, dễ đọc, sao chép và xử lý trong tài liệu sau này.

## Phạm vi áp dụng

Áp dụng khi một dòng trong ảnh chứa từ hai phương án trả lời trở lên, được đánh dấu bằng các nhãn như:

- `A.`
- `B.`
- `C.`
- `D.`
- `E.`

Chỉ tách khi các chữ cái thực sự là nhãn phương án trả lời.

Không tách các chữ cái `A`, `B`, `C`, `D` khi chúng là tên điểm, biến số hoặc một phần của nội dung toán học.

## Quy tắc bắt buộc

- Đặt mỗi phương án trả lời trên một dòng riêng.
- Giữ nguyên thứ tự các phương án trong ảnh.
- Giữ nhãn phương án ở dạng văn bản thường.
- Không đặt nhãn `A.`, `B.`, `C.`, `D.` bên trong `$...$`.
- Viết một dấu cách giữa nhãn phương án và nội dung đáp án.
- Không chèn dòng trống giữa các phương án.
- Không tự thay đổi, sắp xếp hoặc sửa nội dung đáp án.
- Áp dụng đầy đủ các quy tắc LaTeX cho phần toán học của từng đáp án.

## Ví dụ với đáp án là số

Nội dung trong ảnh:

`A. 2 B.3 C.4 D.7`

Kết quả:

```text
A. $2$
B. $3$
C. $4$
D. $7$