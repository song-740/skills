# LaTeX tương thích MathType

## Mục đích

Quy định cách tạo chuỗi LaTeX đầu ra có thể được xử lý bởi MathType Toggle TeX trong quy trình bên ngoài skill.

## Quy tắc chung

- Dùng một dấu gạch chéo cho mỗi lệnh LaTeX.
- Dùng `_` cho chỉ số dưới.
- Dùng `^` cho số mũ.
- Dùng ngoặc nhọn để nhóm nội dung của chỉ số, số mũ và tham số lệnh.
- Không escape dấu gạch dưới dùng để tạo chỉ số.
- Không sử dụng cú pháp Markdown hoặc HTML bên trong công thức.

## Cú pháp ưu tiên

- Phân số: `\frac{a}{b}`
- Căn bậc hai: `\sqrt{x}`
- Căn bậc `n`: `\sqrt[n]{x}`
- Số mũ: `x^{n+1}`
- Chỉ số dưới: `u_n`
- Tổng: `\sum`
- Tích: `\prod`
- Tích phân: `\int`
- Giới hạn: `\lim`
- Phép nhân chấm: `\cdot`
- Phép nhân chéo: `\times`
- Không bằng: `\ne`
- Bé hơn hoặc bằng: `\le`
- Lớn hơn hoặc bằng: `\ge`
- Thuộc: `\in`
- Không thuộc: `\notin`
- Vô cực: `\infty`

## Dấu phẩy trong công thức

- Viết mọi dấu phẩy toán học thành `{,}`.
- Áp dụng cho dấu phẩy thập phân, tọa độ, danh sách và tập hợp.
- Không thay đổi dấu phẩy thuộc câu văn.

Ví dụ:

- `$2{,}5$`
- `$\left(x{,}y\right)$`
- `$\mathit{A}\left(1{,}2\right)$`

## Dấu câu

- Đặt dấu chấm, dấu phẩy hoặc dấu hai chấm thuộc câu văn ở ngoài `$...$`.

Đúng:

`Cho hàm số $y=x^2$.`

Sai:

`Cho hàm số $y=x^2.$`

## Không được làm

- Không viết `u\_n` thay cho `u_n`.
- Không dùng `\\frac` thay cho `\frac`.
- Không dùng `\text{...}` để chứa tiếng Việt.
- Không đưa đơn vị đo vào trong công thức.
- Không tự đổi dấu nhân, dấu chấm hoặc cấu trúc phân số.