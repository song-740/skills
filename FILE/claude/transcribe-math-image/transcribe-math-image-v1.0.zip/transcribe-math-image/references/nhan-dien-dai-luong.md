# Nhận diện đại lượng toán học đứng trong câu văn

## Mục đích

Quy định khi nào một chữ cái hoặc một con số đứng lẻ trong câu văn phải được bọc trong `$...$`, và khi nào phải giữ nguyên là văn bản thường.

Reference này áp dụng cho chữ cái/số nằm rải rác trong câu, không phải là cả một biểu thức đã rõ ràng (biểu thức có `+ - × ÷ = < > căn phân số...` thì luôn luôn bọc `$...$`, không cần tra reference này).

## Nguyên tắc cốt lõi

Bọc `$...$` nếu chữ cái hoặc con số đó đóng vai trò **đại lượng toán học**: một biến, một tham số, hoặc một giá trị số cụ thể đang được lập luận, định nghĩa, hoặc tính toán trong nội dung toán học.

Giữ nguyên văn bản thường nếu chữ cái hoặc con số đó chỉ đóng vai trò **nhãn/chỉ số tổ chức nội dung**: đánh số câu, đánh số bài, nhãn phương án, số trang... — bản thân nó không phải là đối tượng đang được tính toán hay suy luận.

## Các trường hợp PHẢI bọc `$...$`

- Biến hoặc tham số trong định nghĩa, giả thiết, tính chất: "cho số dương $a$", "với mọi $x$", "hằng số $k$".
- Số cụ thể đang được nói đến như một giá trị toán học: "số $0$ cũng được gọi là...", "khi $a=1$", "nghiệm bằng $2$".
- Biến hoặc số xuất hiện trong một khẳng định toán học dù chỉ đứng một mình: "ta có $n$ chẵn", "vậy $a>0$".
- Số 0, số âm, số vô tỉ được nhắc tới như một giá trị: "chia cho $0$ là vô nghĩa".

## Các trường hợp GIỮ NGUYÊN văn bản thường

- Số thứ tự của câu, bài, ví dụ, chương, trang: "Bài 3", "Câu 5", "Ví dụ 2", "trang 10".
- Nhãn phương án trả lời: "A.", "B.", "C.", "D." (xem thêm `references/tach-dap-an.md`).
- Chữ cái là một phần của từ tiếng Việt bình thường, không phải ký hiệu toán học đứng độc lập.
- Số đếm thuần túy không liên quan đến lập luận toán học của bài, ví dụ số trong tên chương/mục lục, số hiệu định lý dùng để tham chiếu ("Định lý 1").

## Cách phân biệt khi không chắc chắn

Tự hỏi: nếu xóa chữ/số này đi, mệnh đề toán học có còn đúng nghĩa không?

- Nếu chữ/số đó là một phần của lập luận, giả thiết, hoặc kết luận toán học → đó là đại lượng toán học → bọc `$...$`.
- Nếu chữ/số đó chỉ giúp người đọc định vị nội dung (số thứ tự, nhãn) và không tham gia vào phép toán hay lập luận → giữ văn bản thường.

## Ví dụ đúng

Ảnh gốc:

```
Với số dương a, số căn a được gọi là căn bậc hai số học của a.
Số 0 cũng được gọi là căn bậc hai số học của 0.
```

Kết quả đúng:

```text
Với số dương $a$, số $\sqrt{a}$ được gọi là căn bậc hai số học của $a$.
Số $0$ cũng được gọi là căn bậc hai số học của $0$.
```

Ảnh gốc:

```
Bài 3. Cho số dương a thỏa mãn a > 1. Tính giá trị biểu thức khi a = 2.
```

Kết quả đúng:

```text
Bài 3. Cho số dương $a$ thỏa mãn $a>1$. Tính giá trị biểu thức khi $a=2$.
```

Lưu ý: "Bài 3" giữ nguyên văn bản thường vì đây là số thứ tự bài, không phải đại lượng toán học; "a" và "a > 1" là đại lượng toán học nên phải bọc `$...$`.

## Ví dụ sai

- Sai vì bỏ sót: `Với số dương a, số $\sqrt{a}$ được gọi là căn bậc hai số học của a.` (hai chữ "a" đứng lẻ không được bọc)
- Sai vì bọc nhầm nhãn: `$Bài 3$. Cho số dương $a$...` (số thứ tự bài không phải đại lượng toán học)
- Sai vì bọc nhầm nhãn phương án: `$A$. 2 $B$. 3` (nhãn phương án phải giữ văn bản thường, xem `references/tach-dap-an.md`)
