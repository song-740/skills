# Ký hiệu hình học

## Mục đích

Quy định cách chuyển tên điểm, đoạn thẳng, đường thẳng, mặt phẳng, hình, vectơ và tam giác sang LaTeX tương thích với quy trình MathType.

## Tên điểm và chuỗi chữ cái

Dùng `\mathit{...}` cho tên các đối tượng hình học:

- Điểm `A`: `$\mathit{A}$`
- Đoạn thẳng `AB`: `$\mathit{AB}$`
- Tam giác có các đỉnh `ABC`: `$\mathit{ABC}$`
- Tứ giác `ABCD`: `$\mathit{ABCD}$`

Không dùng:

- `$A$`
- `$AB$`
- `$\mathrm{AB}$`
- `$\text{AB}$`

## Nhãn đáp án

Giữ `A.`, `B.`, `C.`, `D.` ở dạng văn bản nếu chúng là nhãn phương án.

## Tam giác

- Dùng `\Delta`.
- Không dùng `\triangle`.
- Đặt tên các đỉnh trong `\mathit{...}`.

Ví dụ:

- `$\Delta\mathit{ABC}$`
- `$\Delta\mathit{AEF}\sim\Delta\mathit{ACE}$`
- `$\Delta\mathit{ABC}\cong\Delta\mathit{DEF}$`

Nếu từ “tam giác” là một phần của câu tiếng Việt, giữ từ đó ngoài công thức:

`Hai tam giác $\Delta\mathit{AEF}$ và $\Delta\mathit{ACE}$ đồng dạng với nhau.`

## Tọa độ

Dùng `{,}` cho dấu phẩy và ngoặc co giãn:

- `$\mathit{A}\left(1{,}2\right)$`
- `$\mathit{M}\left(x_0{,}y_0\right)$`