# Dấu ngoặc toán học

## Mục đích

Quy định cách viết dấu ngoặc hiển thị trong chuỗi LaTeX đầu ra để tạo được dấu ngoặc co giãn khi chuỗi được xử lý bằng MathType Toggle TeX.

## Phạm vi

Áp dụng cho dấu ngoặc hiển thị bên trong `$...$`.

Không áp dụng cho:

- Ngoặc thuộc văn bản tự nhiên.
- Ngoặc quanh chú thích hoặc đơn vị đo.
- Ngoặc nhọn dùng để nhóm tham số LaTeX.

## Quy tắc bắt buộc

- Ngoặc tròn: `\left(...\right)`
- Ngoặc vuông: `\left[...\right]`
- Ngoặc nhọn hiển thị: `\left\{...\right\}`
- Giá trị tuyệt đối: `\left|...\right|`
- Chuẩn: `\left\|...\right\|`

Áp dụng kể cả khi biểu thức bên trong đơn giản.

## Ngoặc một phía

- `\left\{...\right.`
- `\left....\right\}`
- `\left|...\right.`
- `\left....\right|`

## Ví dụ đúng

- `$\left(-1\right)$`
- `$\left(x+1\right)^2$`
- `$\left[\frac{a+b}{c+d}\right]$`
- `$\left\{1{,}2{,}3\right\}$`
- `$\left|x-1\right|$`
- `$\left\|x\right\|$`

## Ví dụ sai

- `$(-1)$`
- `$(x+1)^2$`
- `$[\frac{a+b}{c+d}]$`
- `$\{1{,}2{,}3\}$`
- `$|x-1|$`
- `$||x||$`

## Ngoặc cấu trúc LaTeX

Không thay đổi ngoặc nhọn dùng trong cú pháp:

- `\frac{a}{b}`
- `x^{n+1}`
- `u_{n+1}`
- `\sqrt{x}`
- `\mathit{ABC}`