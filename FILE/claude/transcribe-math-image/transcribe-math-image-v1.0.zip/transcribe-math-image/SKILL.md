---
name: transcribe-math-image
description: Chuyển hình ảnh, ảnh chụp màn hình hoặc trang scan có văn bản và công thức toán học thành văn bản TXT thô có thể sao chép. Chép nguyên văn nội dung ngôn ngữ tự nhiên và chuyển phần toán học sang LaTeX đặt trong `$...$`, sử dụng cú pháp tương thích với MathType Toggle TeX. Sử dụng khi người dùng yêu cầu chuyển ảnh toán sang văn bản, TXT, LaTeX hoặc MathType-ready LaTeX.
---

# Chuyển ảnh toán sang TXT LaTeX

## Phạm vi nhiệm vụ

Chỉ thực hiện bước chuyển nội dung trong ảnh thành văn bản TXT thô.

Không tạo DOCX, không chạy script, không thực hiện Toggle TeX và không kiểm tra đối tượng MathType sau chuyển đổi.

## Quy trình

1. Kiểm tra toàn bộ ảnh trước khi chép.
2. Xác định đúng thứ tự đọc.
3. Chép nguyên văn nội dung ngôn ngữ tự nhiên.
4. Xác định chính xác các phần thuộc nội dung toán học, kể cả chữ cái hoặc con số đứng lẻ trong câu văn (theo `references/nhan-dien-dai-luong.md`).
5. Chuyển phần toán học sang LaTeX tương thích với MathType Toggle TeX.
6. Đặt mỗi phần toán học bên trong `$...$`.
7. Nếu một dòng trong ảnh chứa từ hai phương án trả lời trở lên (A., B., C., D...), tách theo `references/tach-dap-an.md`.
8. Áp dụng các tài liệu tham chiếu phù hợp.
9. Kiểm tra toàn bộ kết quả trước khi xuất.
10. Trả kết quả trong một khối văn bản thuần để người dùng sao chép.

## Quy tắc đọc ảnh

- Đọc từ trên xuống dưới và từ trái sang phải, trừ khi bố cục thể hiện thứ tự khác.
- Giữ nguyên số thứ tự câu, ký hiệu đáp án, dấu câu và thứ tự nội dung.
- Giữ nguyên biểu thức, chỉ số, số mũ, phân số, căn thức và ký hiệu toán học.
- Không tự sửa lỗi chính tả hoặc lỗi nội dung xuất hiện trong ảnh.
- Không tự giải bài, rút gọn biểu thức hoặc thay đổi ký hiệu.
- Ghi `[không rõ]` tại đúng vị trí không thể nhận dạng.
- Không âm thầm phỏng đoán ký tự bị mờ.

## Phân tách văn bản và toán học

- Chỉ đặt nội dung toán học thực sự bên trong `$...$`.
- Không đặt tiếng Việt, lời dẫn, lời giải thích hoặc đơn vị đo bên trong `$...$`.
- Giữ nhãn đáp án như `A.`, `B.`, `C.`, `D.` ở dạng văn bản thường.
- Đặt dấu câu thuộc câu văn ở ngoài `$...$`.
- Không sử dụng `\text{...}` để đưa câu tiếng Việt vào công thức.
- Không chuyển toàn bộ một câu hỗn hợp văn bản và toán học thành một công thức.
- Bọc `$...$` cho MỌI chữ cái hoặc con số đứng lẻ trong câu văn nếu nó là một đại lượng toán học (biến, tham số, giá trị số đang được lập luận) — không chỉ bọc khi đã thành một biểu thức có ký hiệu toán học rõ ràng. Xem tiêu chí nhận diện tại `references/nhan-dien-dai-luong.md`.
- Không bọc `$...$` cho số thứ tự câu/bài/ví dụ/trang hoặc nhãn phương án — đây là nhãn tổ chức nội dung, không phải đại lượng toán học.

## Tài liệu tham chiếu

- Luôn đọc `references/latex-mathtype.md` trước khi chuyển công thức toán học.
- Luôn đọc `references/nhan-dien-dai-luong.md` trước khi chép để biết chữ cái/số nào đứng lẻ trong câu phải bọc `$...$` và chữ/số nào là nhãn giữ nguyên văn bản thường.
- Đọc `references/dau-ngoac.md` khi công thức có ngoặc tròn, ngoặc vuông, ngoặc nhọn, giá trị tuyệt đối, chuẩn hoặc ngoặc một phía.
- Đọc `references/hinh-hoc.md` khi ảnh có điểm, đoạn thẳng, đường thẳng, mặt phẳng, vectơ, góc, hình hoặc tam giác.
- Đọc `references/tach-dap-an.md` khi một dòng trong ảnh chứa từ hai phương án trả lời (A., B., C., D...) trở lên.

## Định dạng đầu ra

- Trả duy nhất nội dung đã chép nếu người dùng không yêu cầu giải thích.
- Đặt kết quả trong một khối mã văn bản để có thể sao chép.
- Không thêm lời mở đầu hoặc kết luận vào trong khối kết quả.
- Không chèn dòng trống giữa các dòng.
- Chỉ xuống dòng khi kết thúc câu hỏi, phương án hoặc dòng nội dung tương ứng trong ảnh.
- Không đặt nhiều phương án trả lời trên cùng một dòng.
- Giữ nguyên `$...$` và các lệnh LaTeX thô trong kết quả.
- Không xóa dấu `$` và không chuyển công thức thành định dạng khác.

## Kiểm tra đầu ra

Trước khi trả kết quả, kiểm tra:

- Nội dung đã được chép đầy đủ và đúng thứ tự.
- Không có nội dung tự suy diễn.
- Mỗi công thức đều nằm trong `$...$`.
- Không có tiếng Việt hoặc đơn vị đo bên trong `$...$`.
- Dấu câu của câu văn nằm ngoài công thức.
- LaTeX tuân thủ `references/latex-mathtype.md`.
- Dấu ngoặc tuân thủ `references/dau-ngoac.md`.
- Ký hiệu hình học tuân thủ `references/hinh-hoc.md`.
- Các phương án trả lời trên cùng một dòng đã được tách theo `references/tach-dap-an.md`.
- Không có chữ cái hoặc con số nào là đại lượng toán học mà bị bỏ sót ngoài `$...$` (theo `references/nhan-dien-dai-luong.md`).
- Không có nhãn số thứ tự hoặc nhãn phương án nào bị bọc nhầm vào `$...$`.
- Không có dòng trống không cần thiết.
